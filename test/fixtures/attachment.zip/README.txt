Public CDS670 attachment verification fixture. No student or private data.
